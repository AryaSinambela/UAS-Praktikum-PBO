public class ParkingArea {
    
}
