public class Vehicle {
    
}
